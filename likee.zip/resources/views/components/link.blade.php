<div class="text-center mt-2">
    <a href="{{ $url ? $url : '/' }}">{{$slot}}</a>
</div>