@error($for)
<p class="text-danger">{{ $message }}</p>
@enderror