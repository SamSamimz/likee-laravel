<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MainLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card col-8 mx-auto">
            <img id="profilePic" style="cursor: pointer; height: 300px;width:400px;border-radius:50%" src="<?php echo e('\storage/'.$user->image->path); ?>" class="card-img-top pointer mx-auto" alt="">
            <div class="card-body">
                <h3><?php echo e($user->name); ?></h3>
                <p><?php echo e($user->email); ?></p>
                <h5>Total: <?php echo e($total); ?> <?php echo e(Str::plural('like', $total)); ?></h5>
                
            </div>
          </div>


          
    <div class="col-9 mx-auto">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-light p-3 mt-2 rounded">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex gap-2 mb-2">
                        <a href="<?php echo e(route('userProfile',$post->user)); ?>"><img style="width: 54px; height: 54px; border-radius: 50%" src="<?php echo e($post->user->image ? '\storage/'.$post->user->image->path : '/storage/profiles/person.jpg'); ?>" />
                        </a>
                        <div class="">
                            <h6><a href="<?php echo e(route('userProfile',$post->user)); ?>" class="text-black"><?php echo e($post->user->name); ?></a></h6>
                            <p class="text-secondary"><?php echo e($post->created_at->diffForHumans()); ?></p>
                        </div>
                    </div>
    
                    <div class="dropdown">
                        <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <ion-icon name="ellipsis-horizontal-outline"></ion-icon>
                        </button>
                        <ul class="dropdown-menu">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if($post->user_id === auth()->user()->id): ?>
                                    <li><a class="dropdown-item" href="#">Edit</a></li>
                                <?php endif; ?>
                                <li><a class="dropdown-item" href="#">Save</a></li>
                            <?php endif; ?>
                          <li><a class="dropdown-item" href="<?php echo e(route('download',$post)); ?>">Download Image</a></li>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                          <li><form action="<?php echo e(route('posts.destroy',$post)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="dropdown-item">Delete Post</button>
                            </form></li>
                            <?php endif; ?>
                        </ul>
                      </div>
    
                </div>
                <div><?php echo e($post->title); ?></div>
                <a href="<?php echo e(route('posts.show',$post)); ?>">
                    <img style="cursor: pointer" class="img-fluid" src="<?php echo e('\storage/'.$post->image); ?>" alt="">
                </a>
    
                <div class="text-danger d-flex align-items-center justify-content-between px-2">
                    <?php if($post->likes->count() > 0): ?>
                    <span class="pt-1 px-2"><?php echo e($post->likes->count()); ?> <?php echo e(Str::plural('like', $post->likes->count())); ?></span>
                    <?php endif; ?>
                    <?php if($post->comments->count() > 0): ?>
                    <span class="pt-1 px-2"><?php echo e($post->comments->count()); ?> <?php echo e(Str::plural('comment', $post->comments->count())); ?></span>
                    <?php endif; ?>
                </div>
    
                <?php if(auth()->guard()->check()): ?>    
                <div class="py-3 d-flex align-items-center justify-content-between">
                    <form action="<?php echo e(route('like.post',$post)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="d-flex <?php if($post->likedBy(auth()->user())): ?>
                            text-primary
                            <?php endif; ?> align-items-center gap-1"><ion-icon name="thumbs-up-outline"></ion-icon><?php if($post->likedBy(auth()->user())): ?>
                            UnLike
                            <?php else: ?>
                            Like
                            <?php endif; ?></button>
                        </form>
                        <a href="<?php echo e(route('posts.show',$post)); ?>">
                            <Button class="d-flex align-items-center gap-1"><ion-icon name="chatbubble-ellipses-outline"></ion-icon>Comments</Button>
                        </a>
                    </div>
                    <?php endif; ?>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>

<?php /**PATH G:\LaraProject\likee\resources\views/userProfile.blade.php ENDPATH**/ ?>