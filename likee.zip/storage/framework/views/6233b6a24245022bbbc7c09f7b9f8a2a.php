<div class="text-center mt-2">
    <a href="<?php echo e($url ? $url : '/'); ?>"><?php echo e($slot); ?></a>
</div><?php /**PATH G:\LaraProject\likee\resources\views/components/link.blade.php ENDPATH**/ ?>