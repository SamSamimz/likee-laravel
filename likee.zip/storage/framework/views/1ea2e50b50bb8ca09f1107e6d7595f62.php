<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MainLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="col-9 mx-auto">

        <a href="<?php echo e(route('posts.create')); ?>">
            <div class="col-12 text-center py-3 bg-light mt-3 rounded">
                <span class="text-secondary"><ion-icon style="font-size: 80px" name="add-circle-outline"></ion-icon></span>
                <p>What's cooking?</p>
            </div>
        </a>
            
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-light p-3 mt-2 rounded">
            <div class="d-flex align-items-center justify-content-between">
                <div class="d-flex gap-2 mb-2">
                    <a href="<?php echo e(route('userProfile',$post->user)); ?>"><img style="width: 54px; height: 54px; border-radius: 50%" src="<?php echo e($post->user->image ? '\storage/'.$post->user->image->path : '/storage/profiles/person.jpg'); ?>" />
                    </a>
                    <div class="">
                        <h6><a href="<?php echo e(route('userProfile',$post->user)); ?>" class="text-black"><?php echo e($post->user->name); ?></a></h6>
                        <p class="text-secondary"><?php echo e($post->created_at->diffForHumans()); ?></p>
                    </div>
                </div>

                <div class="dropdown">
                    <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <ion-icon name="ellipsis-horizontal-outline"></ion-icon>
                    </button>
                    <ul class="dropdown-menu">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if($post->user_id === auth()->user()->id): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('posts.edit',$post)); ?>">Edit</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="#">Save</a></li>
                        <?php endif; ?>
                      <li><a class="dropdown-item" href="<?php echo e(route('download',$post)); ?>">Download Image</a></li>
                    </ul>
                  </div>

            </div>
            <div><?php echo e($post->title); ?></div>
            <a href="<?php echo e(route('posts.show',$post)); ?>">
                <img style="cursor: pointer;width:100%;height:470px" class="img-fluid" src="<?php echo e('\storage/'.$post->image); ?>" alt="">
            </a>

            <div class="text-danger d-flex align-items-center justify-content-between px-2">
                <?php if($post->likes->count() > 0): ?>
                <span class="pt-1 px-2"><?php echo e($post->likes->count()); ?> <?php echo e(Str::plural('like', $post->likes->count())); ?></span>
                <?php endif; ?>
                <?php if($post->comments->count() > 0): ?>
                <span class="pt-1 px-2"><?php echo e($post->comments->count()); ?> <?php echo e(Str::plural('comment', $post->comments->count())); ?></span>
                <?php endif; ?>
            </div>

            <?php if(auth()->guard()->check()): ?>    
            <div class="py-3 d-flex align-items-center justify-content-between">
                <form action="<?php echo e(route('like.post',$post)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="d-flex <?php if($post->likedBy(auth()->user())): ?>
                        text-primary
                        <?php endif; ?> align-items-center gap-1"><ion-icon name="thumbs-up-outline"></ion-icon><?php if($post->likedBy(auth()->user())): ?>
                        UnLike
                        <?php else: ?>
                        Like
                        <?php endif; ?></button>
                    </form>
                    <a href="<?php echo e(route('posts.show',$post)); ?>">
                        <Button class="d-flex align-items-center gap-1"><ion-icon name="chatbubble-ellipses-outline"></ion-icon>Comments</Button>
                    </a>
                </div>
                <?php endif; ?>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH G:\LaraProject\likee\resources\views/home.blade.php ENDPATH**/ ?>