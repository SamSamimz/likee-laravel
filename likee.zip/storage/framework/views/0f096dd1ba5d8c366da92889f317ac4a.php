<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MainLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card col-8">
        <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <img id="profilePic" style="cursor: pointer; height: 400px;" src="<?php echo e($profilePic); ?>" class="card-img-top pointer" alt="<?php echo e(auth()->user()->name); ?>">
            <input class="d-none" type="file" name="image" id="inputFile">
            <?php if (isset($component)) { $__componentOriginal7ec225ec96001a00becbb6d24d977476 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ec225ec96001a00becbb6d24d977476 = $attributes; } ?>
<?php $component = App\View\Components\Error::resolve(['for' => 'image'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Error::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $attributes = $__attributesOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__attributesOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $component = $__componentOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__componentOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
            <div class="card-body">
                <div class="mb-3">
                    <h5 class="card-title">Name :</h5>
                    <input type="text" class="form-control" name="name" value="<?php echo e(auth()->user()->name); ?>">
                    <?php if (isset($component)) { $__componentOriginal7ec225ec96001a00becbb6d24d977476 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ec225ec96001a00becbb6d24d977476 = $attributes; } ?>
<?php $component = App\View\Components\Error::resolve(['for' => 'name'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Error::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $attributes = $__attributesOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__attributesOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $component = $__componentOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__componentOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <h5 class="card-title">Email :</h5>
                    <input type="text" class="form-control" name="email" value="<?php echo e(auth()->user()->email); ?>">
                    <?php if (isset($component)) { $__componentOriginal7ec225ec96001a00becbb6d24d977476 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ec225ec96001a00becbb6d24d977476 = $attributes; } ?>
<?php $component = App\View\Components\Error::resolve(['for' => 'email'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Error::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $attributes = $__attributesOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__attributesOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $component = $__componentOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__componentOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
                </div>
                <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve(['color' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
            </div>
          </div>
        </form>

      <?php $__env->startPush('scripts'); ?>
          <script>
            $('#profilePic').click(function () { 
              $('#inputFile').click();
            });
          </script>
      <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>

<?php /**PATH G:\LaraProject\likee\resources\views/settings.blade.php ENDPATH**/ ?>