<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MainLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

  <!-- Modal -->
  <div class="modal fade" id="likeModal" tabindex="-1" aria-labelledby="likeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="likeModalLabel">Liked By</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php $__currentLoopData = $likers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="d-flex align-items-center justify-content-between py-2">
              <a href="<?php echo e(route('userProfile',$liker->user)); ?>"><img style="width: 34px; height: 34px; border-radius: 50%" src="<?php echo e($liker->user->image ? '\storage/'.$liker->user->image->path : '/storage/profiles/person.jpg'); ?>" />
                <?php echo e($liker->user->name); ?></a>
                <p class="text-secondary"><?php echo e($liker->created_at->diffForHumans()); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


      </div>
    </div>
  </div>

        <div class="card col-8 p-3 mx-auto">

          <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex gap-2 mb-2">
                <a href="<?php echo e(route('userProfile',$post->user)); ?>"><img style="width: 54px; height: 54px; border-radius: 50%" src="<?php echo e($post->user->image ? '\storage/'.$post->user->image->path : '/storage/profiles/person.jpg'); ?>" />
                </a>
                <div class="">
                    <h6><a href="<?php echo e(route('userProfile',$post->user)); ?>" class="text-black"><?php echo e($post->user->name); ?></a></h6>
                    <p class="text-secondary"><?php echo e($post->created_at->diffForHumans()); ?></p>
                </div>
            </div>

            <div class="dropdown">
              <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <ion-icon name="ellipsis-horizontal-outline"></ion-icon>
              </button>
              <ul class="dropdown-menu">
                  <?php if(auth()->guard()->check()): ?>
                      <?php if($post->user_id === auth()->user()->id): ?>
                          <li><a class="dropdown-item" href="<?php echo e(route('posts.edit',$post)); ?>">Edit</a></li>
                      <?php endif; ?>
                      <li><a class="dropdown-item" href="#">Save</a></li>
                  <?php endif; ?>
                <li><a class="dropdown-item" href="<?php echo e(route('download',$post)); ?>">Download Image</a></li>
              </ul>
            </div>

          </div>


            <div class="">
              <h4><?php echo e($post->title); ?></h4>
              <p><?php echo e($post->description); ?></p>
          </div>

                <img id="image" style="height: 400px;" src="<?php echo e('\storage/'.$post->image); ?>" class="card-img-top pointer" alt="<?php echo e($post->title); ?>">
                <div class="d-flex align-items-center justify-content-between px-2">
                  <?php if($post->likes->count() > 0): ?>
                  <a data-bs-toggle="modal" data-bs-target="#likeModal" class="text-danger pt-1 px-2"><?php echo e($post->likes->count()); ?> <?php echo e(Str::plural('like', $post->likes->count())); ?></a>
                  <?php endif; ?>
                  <?php if($post->comments->count() > 0): ?>
                  <a href="#comments" class="pt-1 px-2 text-danger"><?php echo e($post->comments->count()); ?> <?php echo e(Str::plural('comment', $post->comments->count())); ?></a>
                  <?php endif; ?>
              </div>

                <?php if(auth()->guard()->check()): ?>    
                <div class="py-3 d-flex align-items-center justify-content-between">
                    <form action="<?php echo e(route('like.post',$post)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="d-flex <?php if($post->likedBy(auth()->user())): ?>
                            text-primary
                            <?php endif; ?> align-items-center gap-1"><ion-icon name="thumbs-up-outline"></ion-icon><?php if($post->likedBy(auth()->user())): ?>
                            UnLike
                            <?php else: ?>
                            Like
                            <?php endif; ?></button>
                        </form>
                        
                        <a href="#comments">
                          <Button class="d-flex align-items-center gap-1"><ion-icon name="chatbubble-ellipses-outline"></ion-icon>Comments</Button>
                      </a>
                    </div>
                    <?php endif; ?>

                
                <form class="mb-2" action="<?php echo e(route('comment.post',$post)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="comment" class="form-label">Comment :</label>
                        <textarea class="form-control" name="comment" id="" cols="20" rows="2" placeholder="Write something..."></textarea>
                        <?php if (isset($component)) { $__componentOriginal7ec225ec96001a00becbb6d24d977476 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ec225ec96001a00becbb6d24d977476 = $attributes; } ?>
<?php $component = App\View\Components\Error::resolve(['for' => 'comment'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Error::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $attributes = $__attributesOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__attributesOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $component = $__componentOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__componentOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Post Comment</button>
                </form>

                
                <div id="comments">
                  <?php if($commenters->count() > 0): ?>
                  <?php $__currentLoopData = $commenters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commenter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="bg-light p-1 m-2 py-2">
                        <div>
                          <a href="<?php echo e(route('userProfile',$commenter->user)); ?>"><img style="width: 34px; height: 34px; border-radius: 50%" src="<?php echo e($commenter->user->image ? '\storage/'.$commenter->user->image->path : '/storage/profiles/person.jpg'); ?>" />
                            <?php echo e($commenter->user->name); ?></a>  
                          </div>
                          <div class="px-2 d-flex align-items-center justify-content-between">
                            <h6><?php echo e($commenter->comment); ?></h6>
                            <p class="text-secondary"><?php echo e($commenter->created_at->diffForHumans()); ?></p>
                          </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?> 
                      <div class="text-center text-secondary">Be the first one to comment.</div>
                  <?php endif; ?>
                    <div><?php echo e($commenters->links('pagination::bootstrap-5')); ?></div>
                </div>


              </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH G:\LaraProject\likee\resources\views/posts/show.blade.php ENDPATH**/ ?>