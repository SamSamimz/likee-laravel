<div class="mb-3">
    <label for="<?php echo e($name); ?>" class="form-label"><?php echo e(ucfirst($name)); ?> :</label>
    <input type="<?php echo e($name === 'password' || $name === 'password_confirmation' ? 'password' : 'text'); ?>" name="<?php echo e($name); ?>" class="form-control" autocomplete="off">
</div><?php /**PATH G:\LaraProject\likee\resources\views/components/input.blade.php ENDPATH**/ ?>