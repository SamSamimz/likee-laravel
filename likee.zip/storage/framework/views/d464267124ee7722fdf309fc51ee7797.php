<div>
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger text-center"><?php echo e(session('error')); ?></div>
    <?php endif; ?>    
</div><?php /**PATH G:\LaraProject\likee\resources\views/components/login-error.blade.php ENDPATH**/ ?>